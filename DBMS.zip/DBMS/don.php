<?php
 
// Username is root
$user = 'root';
$password = '';
 
// Database name is gradingsystem
$database = 'gradingsystem';
 
// Server is localhost with
// port number 3308
$servername='localhost:3308';
$conn = mysqli_connect($servername, $user,$password, $database);
// Checking for connections
if ($conn->connect_error) {
    die('Connect Error (' .
    $conn->connect_errno . ') '.
    $conn->connect_error);
}
?>


