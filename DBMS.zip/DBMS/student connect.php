<?php
include 'don.php';
include_once 'student.php';
if(isset($_POST['submit']))
{    
     $Reg_No = $_POST['Reg'];
     $Name = $_POST['name'];
     $Email = $_POST['email'];
     $dob=$_POST['DOB'];
     $Dept = $_POST['department'];
     $phone = $_POST['phone'];
     $year = $_POST['Year'];
     $sql = "INSERT INTO student(RegNo,Name,Year,Department,DOB,Mobile,Email) VALUES('$Reg_No','$Name','$year','$Dept','$dob','$phone','$Email')";
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>