<!DOCTYPE html>
<html>
<head>
<title> Thiagarajar College of Engineering </title>
<link rel = "stylesheet" type = "text/css" href = "styles.css">
<div class="bar"></div>
<div class = "image">
<img src ="name.png" >
</div>
<div class="bar"></div>
<?php include('link.php');?>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-md-2 col-12">

</div>
<div class="col-md-8 col-12 text-center">
</div>
</div>
</div>
<!-- form starting -->
<div class="container mt-3">
<form action="teacher connect.php" method="post" name="form">
<!-- form started -->
<div class="row">
<div class="col-md-6 col-12">
<div class="row mt-5">
<div class="col-md-4 col-12">
<label for="Reg No">Reg No</label>
</div>
<div class="col-md-8 col-12">
<input type="text" name="Reg" id="Reg" class="form-control" value="" placeholder="Reg No">
</div>
</div>
</div>

<!-- 1 st row ended -->
<div class="row">
<div class="col-md-12 col-12">
<div class="row mt-5">
<div class="col-md-2 col-12">
<label for="Course Code">Course Code</label>
</div>
<div class="col-md-6 col-12">
<select for="Course" name="Course" class="form-control" id="Course">
<option value="">---Select Course code ----</option>
<option value="19DS410">19DS410-ADVANCED DATA STRUCTURES</option>
<option value="19DS412">19DS412-ABSTRACT ALGEBRA</option>
<option value="19DS413">19DS413-DATABASE MANAGEMENT SYSTEMS</option>
<option value="19DS414">19DS414-PREDICTIVE ANALYSIS</option>
<option value="19DS415">19DS415-OPERATING SYSTEMS</option>
</select>
</div>
</div>
</div>
</div>
<br>
<!-- 1 st row ended -->
<div class="col-md-6 col-12">
<div class="row mt-5">
<div class="col-md-4 col-12">
<label for="Mark">Mark</label>
</div>
<div class="col-md-8 col-12">
<input type="text" name="Mark" id="Mark" class="form-control" value="" placeholder="Mark">
</div>
</div>
</div>
</div>
<!-- SUBMIT -->
<br>
<div class="row">
<div class="col-md-12 col-12 text-center">
    <input type="submit" name="submit" value="submit" class="btn btn-primary">
    <input type="reset" name="reset" value="Reset" class="btn btn-">
    <a href="index"><input type="button" name="Exit" value="Home" class="btn btn-"></a>
  </div>
   </div>
<!-- Submit ended -->
</form>
<!-- form ended -->
</div>
<!-- form end -->
</body>
</html>