<?php
include 'don.php';
include_once 'teacher.php';
if(isset($_POST['submit']))
{    
     $RegNo = $_POST['Reg No'];
     $course_code = $_POST['Course'];
     $mark = $_POST['Mark'];
     $sql = "INSERT INTO mark(RegNo,Course_code,MarkObtained)VALUES ('$RegNo','$course_code','$mark')";
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>