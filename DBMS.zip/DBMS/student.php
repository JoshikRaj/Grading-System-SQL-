<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>intro</title>
<?php include('link.php');?>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container-fluid">
<div class="row">
<div class="col-md-2 col-12">
<img src="tce_logo-removebg-preview.png" width="80%">
</div>
<div class="col-md-8 col-12 text-center">
<h1>Thiagarajar College of Engineering</h1>
<h3>University in Madurai, Tamil Nadu</h3>
</div>
</div>
</div>
<!-- form starting -->
<div class="container mt-3">
<form action="student connect.php" method="post" name="form">
<!-- form started -->
<div class="row">
<div class="col-md-6 col-12">
<div class="row mt-5">
<div class="col-md-4 col-12">
<label for="Reg No">Reg No</label>
</div>
<div class="col-md-8 col-12">
<input type="text" name="Reg No" id="Reg No" class="form-control" value="" placeholder="Reg No">
</div>
</div>
</div>
<div class="col-md-6 col-12">
<div class="row mt-5">
<div class="col-md-4 col-12">
<label for="name">name</label>
</div>
<div class="col-md-8 col-12">
<input type="text" name="name" id="name" class="form-control" value="" placeholder="name">
</div>
</div>
</div>
</div>
<!-- 1 st row ended -->
<div class="row">
<div class="col-md-6 col-12">
<div class="row mt-5">
<div class="col-md-4 col-12">
<label for="email">Email-ID</label>
</div>
<div class="col-md-8 col-12">
<input type="email" name="email" id="email" class="form-control" value="" placeholder="email">
</div>
</div>
</div>
<div class="col-md-6 col-12">
<div class="row mt-5">
<div class="col-md-4 col-12">
<label for="Phone">Phone Number</label>
</div>
<div class="col-md-8 col-12">
<input type="text" name="phone" id="phone" class="form-control" value="" placeholder="phone number">
</div>
</div>
</div>
</div>
<!-- 1 st row ended -->
<div class="row">
<div class="col-md-6 col-12">
<div class="row mt-5">
<div class="col-md-4 col-12">
<label for="DOB">DOB</label>
</div>
<div class="col-md-8 col-12">
<input type="date" name="DOB" id="DOB" class="form-control" value="" placeholder="DOB">
</div>
</div>
</div>
<div class="col-md-6 col-12">
<div class="row mt-5">
<div class="col-md-4 col-12">
<label for="Year">Year</label>
</div>
<div class="col-md-8 col-12">
<input type="text" name="Year" id="Year" class="form-control" value="" placeholder="Year">
</div>
</div>
</div>
</div>
<!-- 1 st row ended -->
<div class="row">
<div class="col-md-12 col-12">
<div class="row mt-5">
<div class="col-md-2 col-12">
<label for="department">Department</label>
</div>
<div class="col-md-6 col-12">
<select for="department" name="department" class="form-control" id="department">
<option value="">---Select Department----</option>
<option value="Civil Engineering">Civil Engineering</option>
<option value="Mechanical Engineering">Mechanical Engineering</option>
<option value="Electrical and Electronics Engineering">Electrical and Electronics Engineering</option>
<option value="Electronics and Communication Engineering">Electronics and Communication Engineering</option>
<option value="Computer Science and Engineering">Computer Science and Engineering</option>
<option value="Information Technology">Information Technology</option>
<option value="Mechatronics">Mechatronics</option>
<option value="Computer Science and Business Systems">Computer Science and Business Systems</option>
<option value="Mathematics">Mathematics</option>
<option value="Computer Applications">Computer Applications</option>
<option value="Data Science">Data Science</option>
<option value="Physics">Physics</option>
<option value="Chemistry">Chemistry</option>
<option value="English">English</option>
<option value="Architecture">Architecture</option>
</select>
</div>
</div>
</div>
</div>
<!-- 1 st row ended -->
<!-- SUBMIT -->
<div class="row">
<div class="col-md-12 col-12 text-center">
    <input type="submit" name="submit" value="submit" class="btn btn-primary">
    <input type="reset" name="reset" value="Reset" class="btn btn-primary">
    <a href="index"><input type="button" name="Exit" value="Home" class="btn btn-primary"></a>
  </div>
   </div>
<!-- Submit ended -->
</form>
<!-- form ended -->
</div>
<!-- form end -->
</body>
</html>
